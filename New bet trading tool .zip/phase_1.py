# Phase 1: Interface and Layout
print('Phase 1 loaded')