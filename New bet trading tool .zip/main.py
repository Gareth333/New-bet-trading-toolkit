# Main Entry
import phase_1
import phase_2
import phase_3
import phase_4
print('Bot fully loaded')