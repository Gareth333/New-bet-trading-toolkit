# Phase 2: Odds Scraper and Dutching Logic
print('Phase 2 loaded')